import 'package:flutter/material.dart';
import 'principal.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // TÍTULO CAMBIADO: Refleja el propósito de la app
      title: 'Control de Asistencia RH',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
        ),
        useMaterial3: true,
      ),
      // CLASE DE LOGIN RENOMBRADA (Opcional, pero buena práctica)
      // En tu código original era 'App04', lo mantendré así
      // para consistencia, pero considera renombrarla a 'LoginScreen' o similar.
      home: const App04(),
    );
  }
}

class App04 extends StatefulWidget {
  const App04({super.key});

  @override
  State<App04> createState() => _App04State();
}

class _App04State extends State<App04> {
  final _userController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _userController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        // TÍTULO DE PANTALLA CAMBIADO
        title: Text("Acceso RH - Asistencia"),
        centerTitle: true,
      ),
      body: ListView(
        padding: EdgeInsets.all(20),
        children: [
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                SizedBox(height: 45),
                // ICONO CAMBIADO: Más apropiado para RH/Admin
                Icon(
                  Icons.admin_panel_settings,
                  size: 250,
                  color: colors.primary.withOpacity(0.8),
                ),
                SizedBox(height: 10),
                Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        TextField(
                          controller: _userController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "Usuario (RH)",
                            // ICONO CAMBIADO
                            prefixIcon: Icon(Icons.person),
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        TextField(
                          controller: _passwordController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "Contraseña",
                            // ICONO CAMBIADO
                            prefixIcon: Icon(Icons.lock),
                          ),
                          obscureText: true,
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 60,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // === INICIO DE LÓGICA DE AUTENTICACIÓN ===
                        // ! ESTA ES LA SECCIÓN QUE DEBES REEMPLAZAR !

                        // 1. Obtener datos del formulario
                        String user = _userController.text;
                        String password = _passwordController.text;

                        // 2. Lógica Ficticia Temporal
                        // TODO: Reemplazar esto con la consulta a tu base de datos
                        // (usando el esquema que mencionaste)
                        // Ejemplo:
                        // bool esValido = await authService.login(user, password);

                        if (user == 'rh_admin' && password == 'escuela123') {
                          // 3. Si es válido, navegar a la pantalla principal
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ()),
                          );
                        } else {
                          // 4. Si no es válido, mostrar error
                          showModalBottomSheet(
                            context: context,
                            builder: (context) {
                              return Container(
                                padding: EdgeInsets.all(20),
                                height: 100,
                                child: Center(
                                  child: Text(
                                    "Usuario o contraseña incorrectos",
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.red,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              );
                            },
                          );
                        }
                        // === FIN DE LÓGICA DE AUTENTICACIÓN ===
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_box),
                          SizedBox(
                            width: 6,
                          ),
                          Text("Ingresar"),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    TextButton(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          builder: (context) {
                            return Container(
                                padding: EdgeInsets.all(20),
                                height: 100,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.email,
                                      color: colors.primary,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      "Contacte al administrador del sistema.",
                                      style: TextStyle(fontSize: 16),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ));
                          },
                        );
                      },
                      child: Text("Olvide la contraseña"),
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
